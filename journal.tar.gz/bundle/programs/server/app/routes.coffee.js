(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
if (Meteor.isClient) {
  Router.route('/', (function() {
    this.render('entries');
  }), {
    name: 'new_entry'
  });
  Router.route('/analysis', function() {
    this.render('Analysis');
  });
  Router.route('entry/:entryDate', {
    action: function() {
      var params;
      params = this.params;
      this.render('entries', {
        data: function() {
          return Entries.findOne({
            entry_date: params.entryDate.replace(/-/g, '/'),
            owner: Meteor.userId()
          });
        }
      });
    },
    name: 'entry'
  });
}

})();

//# sourceMappingURL=routes.coffee.js.map
